package com.salesmaster.app.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.fragment.app.Fragment
import okhttp3.*
import org.json.JSONObject
import java.io.IOException
import com.salesmaster.app.BuildConfig

class AiFragment: Fragment() {

    private val client = OkHttpClient()

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        val root = LinearLayout(requireContext()).apply {
            orientation = LinearLayout.VERTICAL
            val pad = (16 * resources.displayMetrics.density).toInt()
            setPadding(pad, pad, pad, pad)
        }

        val input = EditText(requireContext()).apply {
            hint = "Ask the AI for a rebuttal..."
        }
        val btn = Button(requireContext()).apply { text = "Send" }
        val output = TextView(requireContext())

        btn.setOnClickListener {
            val prompt = input.text.toString()
            if (prompt.isNotBlank()) callOpenAi(prompt) { text ->
                requireActivity().runOnUiThread { output.text = text }
            }
        }

        root.addView(input)
        root.addView(btn)
        root.addView(output)
        return root
    }

    private fun callOpenAi(userText: String, onResult: (String) -> Unit) {
        val apiKey = if (BuildConfig.OPENAI_API_KEY.isNotBlank()) BuildConfig.OPENAI_API_KEY
            else System.getenv("OPENAI_API_KEY") ?: ""

        if (apiKey.isBlank()) {
            onResult("Missing OPENAI_API_KEY (set it in GitHub repo secrets).")
            return
        }
        val json = JSONObject()
            .put("model", "gpt-4o-mini")
            .put("messages", org.json.JSONArray()
                .put(JSONObject().put("role","system").put("content","You are SalesMaster, a concise sales rebuttal assistant."))
                .put(JSONObject().put("role","user").put("content", userText))
            )

        val body = RequestBody.create(MediaType.parse("application/json"), json.toString())
        val req = Request.Builder()
            .url("https://api.openai.com/v1/chat/completions")
            .header("Authorization", "Bearer $apiKey")
            .post(body)
            .build()

        client.newCall(req).enqueue(object: Callback {
            override fun onFailure(call: Call, e: IOException) {
                onResult("Network error: ${e.message}")
            }
            override fun onResponse(call: Call, response: Response) {
                response.use {
                    if (!response.isSuccessful) {
                        onResult("API error: ${response.code()}")
                        return
                    }
                    val resp = JSONObject(response.body()!!.string())
                    val text = resp.getJSONArray("choices").getJSONObject(0)
                        .getJSONObject("message").getString("content")
                    onResult(text)
                }
            }
        })
    }
}
